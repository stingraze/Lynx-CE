/* Standalone parser test (host build): gcc -o html_parse_test html_parse_test.c html_parse.c */
#include <stdio.h>
#include <string.h>
#include "html_parse.h"

static const char *sample =
    "<html><head><title>Test Page</title></head>"
    "<body>"
    "<h1>Welcome</h1>"
    "<p>Visit <a href=\"/about\">About Us</a> for info.</p>"
    "<table><tr><th>Name</th><th>Value</th></tr>"
    "<tr><td>Alpha</td><td>100</td></tr>"
    "<tr><td>Beta</td><td>200</td></tr></table>"
    "<form method=\"post\" action=\"/search\">"
    "<input type=\"text\" name=\"q\" value=\"\">"
    "<input type=\"hidden\" name=\"lang\" value=\"en\">"
    "</form>"
    "</body></html>";

int main(void)
{
    html_document_t doc;
    char out[4096];
    int len;

    html_parse_document(sample, &doc);

    printf("Title: %s\n", doc.title);
    printf("Links: %d\n", doc.num_links);
    if (doc.num_links > 0) {
        printf("  [1] %s => %s\n", doc.links[0].text, doc.links[0].url);
    }
    printf("Forms: %d (inputs: %d)\n", doc.num_forms, doc.forms[0].num_inputs);
    printf("Tables: %d (%dx%d)\n", doc.num_tables,
           doc.tables[0].num_rows, doc.tables[0].num_cols);

    len = html_render_text(sample, &doc, out, sizeof(out));
    printf("\n--- Rendered ---\n%s\n--- End (%d bytes) ---\n", out, len);

    {
        char abs[512];
        html_make_absolute_url("http://example.com/dir/page.html",
                               "../other.html", abs, sizeof(abs));
        printf("Resolved: %s\n", abs);
    }

    return 0;
}
