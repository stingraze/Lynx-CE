#include <windows.h>     // Windows CE definitions
#include "winsock2.h"    // Local header, same directory
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "net_transport.h"
#include "html_parse.h"

/*
 (C)Tsubasa Kato - Inspire Search Corporation - 2024
 Lynx-CE Ver. 0.02
 * Minimal text browser for Windows CE with a Lynx-like prompt:
 *   - Press 'g' to type a URL: e.g. http://example.com/
 *   - Press 'l' to list and follow links on the current page
 *   - Press 'f' to fill in a form text field and submit
 *   - Press 'q' to quit
 *
 * HTML body, links, forms, and tables are parsed by html_parse.c.
 */

#define PAGE_BUF_SIZE 65536

static html_document_t gDoc;
static char gCurrentURL[512] = "";

//------------------------------------------------------------------------------
// URL parser for http:// and https://
static int parse_url(const char *url, net_scheme_t *scheme, char *host, int hostLen,
                     char *path, int pathLen, unsigned short *port)
{
    const char *p = NULL;
    const char *slash = NULL;
    const char *colon = NULL;
    char hostport[256] = {0};

    if (strncmp(url, "https://", 8) == 0) {
        *scheme = NET_SCHEME_HTTPS;
        *port = 443;
        p = url + 8;
    } else if (strncmp(url, "http://", 7) == 0) {
        *scheme = NET_SCHEME_HTTP;
        *port = 80;
        p = url + 7;
    } else {
        return -1;
    }

    slash = strchr(p, '/');
    if (!slash) {
        strncpy(hostport, p, sizeof(hostport) - 1);
        strcpy(path, "/");
    } else {
        int hpLen = (int)(slash - p);
        if (hpLen <= 0 || hpLen >= (int)sizeof(hostport)) return -1;
        strncpy(hostport, p, hpLen);
        hostport[hpLen] = '\0';
        strncpy(path, slash, pathLen - 1);
        path[pathLen - 1] = '\0';
    }

    colon = strchr(hostport, ':');
    if (colon) {
        int hLen = (int)(colon - hostport);
        if (hLen <= 0 || hLen >= hostLen) return -1;
        strncpy(host, hostport, hLen);
        host[hLen] = '\0';
        *port = (unsigned short)atoi(colon + 1);
    } else {
        strncpy(host, hostport, hostLen - 1);
        host[hostLen - 1] = '\0';
    }

    return 0;
}

//------------------------------------------------------------------------------
static int recv_full_page(net_transport_t *transport, char *buf, int buf_size)
{
    int total = 0;
    int received;

    while (total < buf_size - 1) {
        received = net_transport_recv(transport, buf + total, buf_size - 1 - total);
        if (received <= 0) break;
        total += received;
    }
    buf[total] = '\0';
    return total;
}

//------------------------------------------------------------------------------
static void url_encode(const char *input, char *out, int out_size)
{
    int idx = 0;
    int i;

    for (i = 0; input[i] != '\0' && idx < out_size - 4; i++) {
        char ch = input[i];
        if (ch == ' ') {
            out[idx++] = '+';
        } else if ((ch >= '0' && ch <= '9') ||
                   (ch >= 'A' && ch <= 'Z') ||
                   (ch >= 'a' && ch <= 'z') ||
                   ch == '-' || ch == '_' || ch == '.' || ch == '~') {
            out[idx++] = ch;
        } else {
            idx += snprintf(out + idx, out_size - idx, "%%%02X", (unsigned char)ch);
        }
    }
    out[idx] = '\0';
}

//------------------------------------------------------------------------------
static void display_page(const char *body)
{
    static char rendered[PAGE_BUF_SIZE];
    int len;

    html_parse_document(body, &gDoc);
    len = html_render_text(body, &gDoc, rendered, sizeof(rendered));
    if (len < 0) {
        printf("Page too large to render.\n");
        return;
    }

    printf("----- Page Text -----\n");
    printf("%s\n", rendered);
    printf("----- End -----\n");

    if (gDoc.num_links > 0) {
        printf("(%d link(s) found; press 'l' to list)\n", gDoc.num_links);
    }
    if (gDoc.num_forms > 0) {
        printf("(%d form(s) found; press 'f' to submit)\n", gDoc.num_forms);
    }
    if (gDoc.num_tables > 0) {
        printf("(%d table(s) rendered inline)\n", gDoc.num_tables);
    }
}

//------------------------------------------------------------------------------
// Sends GET or POST, reads full response, parses HTML, prints Lynx-style text.
static void fetch_page(const char *url, const char *post_data, const net_tls_options_t *tls_opts)
{
    char host[256] = {0};
    char path[512] = {0};
    unsigned short port = 0;
    net_scheme_t scheme;
    static char raw_buf[PAGE_BUF_SIZE];
    char *body;
    char request[2048];
    net_tls_options_t effective_tls;
    net_transport_t transport;
    int total;

    if (parse_url(url, &scheme, host, sizeof(host), path, sizeof(path), &port) != 0) {
        printf("Error: Malformed or unsupported URL. Try http://example.com/ or https://example.com/\n");
        return;
    }

    effective_tls = *tls_opts;
    effective_tls.server_name = host;

    if (net_transport_connect(&transport, host, port, scheme, &effective_tls) != 0) {
        printf("connect() failed.\n");
        return;
    }

    if (post_data) {
        snprintf(request, sizeof(request),
                 "POST %s HTTP/1.0\r\n"
                 "Host: %s\r\n"
                 "Connection: close\r\n"
                 "User-Agent: CE-Lynx/1.0\r\n"
                 "Content-Type: application/x-www-form-urlencoded\r\n"
                 "Content-Length: %d\r\n"
                 "\r\n"
                 "%s",
                 path, host, (int)strlen(post_data), post_data);
    } else {
        snprintf(request, sizeof(request),
                 "GET %s HTTP/1.0\r\n"
                 "Host: %s\r\n"
                 "Connection: close\r\n"
                 "User-Agent: CE-Lynx/1.0\r\n\r\n",
                 path, host);
    }

    if (net_transport_send(&transport, request, (int)strlen(request)) <= 0) {
        printf("send() failed.\n");
        net_transport_close(&transport);
        return;
    }

    total = recv_full_page(&transport, raw_buf, sizeof(raw_buf));
    net_transport_close(&transport);

    if (total <= 0) {
        printf("No data received.\n");
        return;
    }

    body = strstr(raw_buf, "\r\n\r\n");
    if (!body) {
        printf("No HTTP body found.\n");
        return;
    }
    body += 4;

    display_page(body);
}

//------------------------------------------------------------------------------
static void follow_link(int index)
{
    char abs_url[512];

    if (index < 1 || index > gDoc.num_links) {
        printf("Invalid link index.\n");
        return;
    }

    if (html_make_absolute_url(gCurrentURL, gDoc.links[index - 1].url,
                               abs_url, sizeof(abs_url)) != 0) {
        printf("Could not resolve link URL.\n");
        return;
    }

    strncpy(gCurrentURL, abs_url, sizeof(gCurrentURL) - 1);
    gCurrentURL[sizeof(gCurrentURL) - 1] = '\0';
}

//------------------------------------------------------------------------------
static void submit_form(int form_index, const net_tls_options_t *tls_opts)
{
    html_form_t *form;
    char post_data[2048];
    char get_url[512];
    char full_action[512];
    int i;
    int first_field = 1;

    if (form_index < 1 || form_index > gDoc.num_forms) {
        printf("Invalid form index.\n");
        return;
    }

    form = &gDoc.forms[form_index - 1];
    if (form->num_inputs == 0) {
        printf("Form has no text inputs.\n");
        return;
    }

    post_data[0] = '\0';
    for (i = 0; i < form->num_inputs; i++) {
        html_input_t *input = &form->inputs[i];
        char enc[512];
        char user_text[256];

        if (strcmp(input->type, "submit") == 0 ||
            strcmp(input->type, "button") == 0) {
            continue;
        }

        if (strcmp(input->type, "hidden") == 0) {
            url_encode(input->value, enc, sizeof(enc));
        } else {
            printf("Enter value for [%s] (%s): ", input->name, input->type);
            fflush(stdout);

            if (!fgets(user_text, sizeof(user_text), stdin)) {
                printf("Error reading input.\n");
                return;
            }
            user_text[strcspn(user_text, "\r\n")] = '\0';

            if (user_text[0] == '\0' && input->value[0] != '\0') {
                strncpy(user_text, input->value, sizeof(user_text) - 1);
                user_text[sizeof(user_text) - 1] = '\0';
            }

            url_encode(user_text, enc, sizeof(enc));
        }

        if (!first_field) {
            strncat(post_data, "&", sizeof(post_data) - strlen(post_data) - 1);
        }
        strncat(post_data, input->name, sizeof(post_data) - strlen(post_data) - 1);
        strncat(post_data, "=", sizeof(post_data) - strlen(post_data) - 1);
        strncat(post_data, enc, sizeof(post_data) - strlen(post_data) - 1);
        first_field = 0;
    }

    if (post_data[0] == '\0') {
        printf("No submittable fields found.\n");
        return;
    }

    if (html_make_absolute_url(gCurrentURL, form->action,
                               full_action, sizeof(full_action)) != 0) {
        printf("Could not resolve form action.\n");
        return;
    }

    if (strcmp(form->method, "post") == 0) {
        strncpy(gCurrentURL, full_action, sizeof(gCurrentURL) - 1);
        gCurrentURL[sizeof(gCurrentURL) - 1] = '\0';
        fetch_page(gCurrentURL, post_data, tls_opts);
    } else {
        snprintf(get_url, sizeof(get_url), "%s?%s", full_action, post_data);
        strncpy(gCurrentURL, get_url, sizeof(gCurrentURL) - 1);
        gCurrentURL[sizeof(gCurrentURL) - 1] = '\0';
        fetch_page(gCurrentURL, NULL, tls_opts);
    }
}

//------------------------------------------------------------------------------
int main(int argc, char **argv)
{
    WSADATA wsa;
    net_tls_options_t tls_opts;

    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        printf("WSAStartup failed.\n");
        return 1;
    }

    memset(&tls_opts, 0, sizeof(tls_opts));
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--tls-insecure") == 0) tls_opts.tls_insecure = 1;
        else if (strncmp(argv[i], "--ca-bundle=", 12) == 0) tls_opts.ca_bundle_path = argv[i] + 12;
    }

    html_document_init(&gDoc);

    printf("CE-Lynx (body/form/table parser)\n");
    printf("Commands: g=Go, l=Links, f=Form, q=Quit\n");

    while (1) {
        printf("\nCurrent URL: %s\n", gCurrentURL[0] ? gCurrentURL : "None");
        printf("Command (g/l/f/q): ");
        fflush(stdout);

        {
            int c = getchar();
            while (getchar() != '\n') { /* discard extra input */ }

            if (c == 'q' || c == 'Q') {
                printf("Bye!\n");
                break;
            } else if (c == 'g' || c == 'G') {
                char url[512];
                printf("Enter URL (e.g. http://example.com/): ");
                fflush(stdout);

                if (fgets(url, sizeof(url), stdin) == NULL) {
                    printf("Error reading URL.\n");
                    continue;
                }
                url[strcspn(url, "\r\n")] = '\0';

                strncpy(gCurrentURL, url, sizeof(gCurrentURL) - 1);
                gCurrentURL[sizeof(gCurrentURL) - 1] = '\0';
                fetch_page(gCurrentURL, NULL, &tls_opts);
            } else if (c == 'l' || c == 'L') {
                if (gDoc.num_links == 0) {
                    printf("No links found on this page.\n");
                } else {
                    int i;
                    for (i = 0; i < gDoc.num_links; i++) {
                        printf("[%d] %s => %s\n", i + 1,
                               gDoc.links[i].text, gDoc.links[i].url);
                    }
                    printf("Enter link number to follow: ");
                    fflush(stdout);

                    {
                        char buf[32];
                        int choice;
                        if (!fgets(buf, sizeof(buf), stdin)) continue;
                        choice = atoi(buf);
                        follow_link(choice);
                        if (choice >= 1 && choice <= gDoc.num_links) {
                            fetch_page(gCurrentURL, NULL, &tls_opts);
                        }
                    }
                }
            } else if (c == 'f' || c == 'F') {
                if (gDoc.num_forms == 0) {
                    printf("No form found on this page.\n");
                } else {
                    int form_choice = 1;
                    if (gDoc.num_forms > 1) {
                        int i;
                        for (i = 0; i < gDoc.num_forms; i++) {
                            printf("[%d] method=%s action=%s inputs=%d\n",
                                   i + 1, gDoc.forms[i].method,
                                   gDoc.forms[i].action, gDoc.forms[i].num_inputs);
                        }
                        printf("Enter form number: ");
                        fflush(stdout);
                        {
                            char buf[32];
                            if (!fgets(buf, sizeof(buf), stdin)) continue;
                            form_choice = atoi(buf);
                        }
                    }
                    submit_form(form_choice, &tls_opts);
                }
            } else {
                printf("Unknown command '%c'\n", c);
            }
        }
    }

    WSACleanup();
    return 0;
}
