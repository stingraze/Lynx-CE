#include "html_parse.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static char html_lower(char c)
{
    if (c >= 'A' && c <= 'Z') {
        return (char)(c + ('a' - 'A'));
    }
    return c;
}

static char *html_strcasestr(const char *haystack, const char *needle)
{
    if (!haystack || !needle) return NULL;
    if (!*needle) return (char*)haystack;

    for (; *haystack; haystack++) {
        if (html_lower(*haystack) == html_lower(*needle)) {
            const char *h = haystack + 1;
            const char *n = needle + 1;
            while (*n && *h && html_lower(*h) == html_lower(*n)) {
                h++;
                n++;
            }
            if (!*n) {
                return (char*)haystack;
            }
        }
    }
    return NULL;
}

static void html_strlower(char *s)
{
    while (*s) {
        *s = html_lower(*s);
        s++;
    }
}

static int html_is_space(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\f';
}

static void html_trim(char *s)
{
    char *start = s;
    char *end;

    while (*start && html_is_space(*start)) start++;
    if (start != s) {
        memmove(s, start, strlen(start) + 1);
    }

    end = s + strlen(s);
    while (end > s && html_is_space(end[-1])) {
        end--;
    }
    *end = '\0';
}

static void html_collapse_spaces(char *s)
{
    char *w = s;
    char *r = s;
    int in_space = 0;

    while (*r) {
        if (html_is_space(*r)) {
            if (!in_space && w > s) {
                *w++ = ' ';
            }
            in_space = 1;
        } else {
            *w++ = *r;
            in_space = 0;
        }
        r++;
    }
    *w = '\0';
}

static void html_collapse_spaces_trim(char *s)
{
    html_collapse_spaces(s);
    html_trim(s);
}

void html_decode_entities(char *text)
{
    char *r = text;
    char *w = text;

    while (*r) {
        if (*r == '&') {
            if (strncmp(r, "&amp;", 5) == 0) {
                *w++ = '&';
                r += 5;
            } else if (strncmp(r, "&lt;", 4) == 0) {
                *w++ = '<';
                r += 4;
            } else if (strncmp(r, "&gt;", 4) == 0) {
                *w++ = '>';
                r += 4;
            } else if (strncmp(r, "&quot;", 6) == 0) {
                *w++ = '"';
                r += 6;
            } else if (strncmp(r, "&apos;", 6) == 0) {
                *w++ = '\'';
                r += 6;
            } else if (strncmp(r, "&nbsp;", 6) == 0) {
                *w++ = ' ';
                r += 6;
            } else if (r[1] == '#') {
                int code = 0;
                const char *p = r + 2;
                if (*p == 'x' || *p == 'X') {
                    p++;
                    while ((*p >= '0' && *p <= '9') ||
                           (html_lower(*p) >= 'a' && html_lower(*p) <= 'f')) {
                        int digit;
                        if (*p >= '0' && *p <= '9') digit = *p - '0';
                        else digit = html_lower(*p) - 'a' + 10;
                        code = code * 16 + digit;
                        p++;
                    }
                } else {
                    while (*p >= '0' && *p <= '9') {
                        code = code * 10 + (*p - '0');
                        p++;
                    }
                }
                if (*p == ';' && code > 0 && code < 256) {
                    *w++ = (char)code;
                    r = (char*)(p + 1);
                } else {
                    *w++ = *r++;
                }
            } else {
                *w++ = *r++;
            }
        } else {
            *w++ = *r++;
        }
    }
    *w = '\0';
}

static int html_get_attr(const char *tag, const char *name, char *out, int out_len)
{
    char search[64];
    const char *pos;
    const char *q1;
    const char *q2;
    int len;

    if (out_len <= 0) return -1;
    out[0] = '\0';

    snprintf(search, sizeof(search), "%s=", name);
    pos = html_strcasestr(tag, search);
    if (!pos) return -1;

    q1 = strchr(pos + strlen(search), '"');
    if (!q1) return -1;
    q2 = strchr(q1 + 1, '"');
    if (!q2) return -1;

    len = (int)(q2 - (q1 + 1));
    if (len <= 0) return -1;
    if (len >= out_len) len = out_len - 1;
    strncpy(out, q1 + 1, len);
    out[len] = '\0';
    return 0;
}

static void html_strip_tags(char *buffer)
{
    char *r = buffer;
    char *w = buffer;
    int in_tag = 0;

    while (*r) {
        if (*r == '<') {
            in_tag = 1;
        } else if (*r == '>') {
            in_tag = 0;
        } else if (!in_tag) {
            *w++ = *r;
        }
        r++;
    }
    *w = '\0';
}

static void html_copy_cell_text(const char *start, const char *end, char *out, int out_len)
{
    char tmp[512];
    int len;

    if (end <= start || out_len <= 0) {
        out[0] = '\0';
        return;
    }

    len = (int)(end - start);
    if (len >= (int)sizeof(tmp)) len = (int)sizeof(tmp) - 1;
    strncpy(tmp, start, len);
    tmp[len] = '\0';

    html_strip_tags(tmp);
    html_decode_entities(tmp);
    html_collapse_spaces_trim(tmp);

    strncpy(out, tmp, out_len - 1);
    out[out_len - 1] = '\0';
}

static const char *html_body_start(const char *html)
{
    const char *open = html_strcasestr(html, "<body");
    const char *close_tag;

    if (!open) return html;
    close_tag = strchr(open, '>');
    if (!close_tag) return html;
    return close_tag + 1;
}

static const char *html_body_end(const char *html, const char *body_start)
{
    const char *end = html_strcasestr(body_start, "</body>");
    if (!end) return html + strlen(html);
    return end;
}

static int html_is_skipped_tag(const char *tag_buf)
{
    return strncmp(tag_buf, "<script", 7) == 0 ||
           strncmp(tag_buf, "<style", 6) == 0 ||
           strncmp(tag_buf, "<noscript", 9) == 0 ||
           strncmp(tag_buf, "<head", 5) == 0;
}

static int html_is_skipped_close(const char *tag_buf)
{
    return strncmp(tag_buf, "</script", 8) == 0 ||
           strncmp(tag_buf, "</style", 7) == 0 ||
           strncmp(tag_buf, "</noscript", 10) == 0 ||
           strncmp(tag_buf, "</head", 6) == 0;
}

static int html_append_char(char *out, int out_len, int *pos, char ch);
static int html_append_str(char *out, int out_len, int *pos, const char *text);
static int html_append_newline(char *out, int out_len, int *pos);

static int html_append_text(char *out, int out_len, int *pos, char *text, int pre_mode)
{
    if (!pre_mode) {
        if (text[0] && html_is_space(text[0]) && *pos > 0) {
            char prev = out[*pos - 1];
            if (!html_is_space(prev) && prev != '\n') {
                if (html_append_char(out, out_len, pos, ' ') != 0) return -1;
            }
        }
        while (text[0] && html_is_space(text[0])) {
            memmove(text, text + 1, strlen(text));
        }
        html_collapse_spaces(text);
    }
    html_decode_entities(text);
    if (text[0] == '\0') return 0;
    return html_append_str(out, out_len, pos, text);
}

static int html_append_char(char *out, int out_len, int *pos, char ch)
{
    if (*pos + 1 >= out_len) return -1;
    out[(*pos)++] = ch;
    out[*pos] = '\0';
    return 0;
}

static int html_append_str(char *out, int out_len, int *pos, const char *text)
{
    while (*text) {
        if (html_append_char(out, out_len, pos, *text) != 0) return -1;
        text++;
    }
    return 0;
}

static int html_append_newline(char *out, int out_len, int *pos)
{
    if (*pos > 0 && out[*pos - 1] != '\n') {
        return html_append_char(out, out_len, pos, '\n');
    }
    return 0;
}

static void html_render_table(const html_table_t *table, char *out, int out_len, int *pos)
{
    int col_widths[HTML_MAX_TABLE_COLS];
    int r, c;
    int width;

    if (table->num_rows <= 0 || table->num_cols <= 0) return;

    memset(col_widths, 0, sizeof(col_widths));
    for (c = 0; c < table->num_cols; c++) {
        for (r = 0; r < table->num_rows; r++) {
            width = (int)strlen(table->cells[r][c]);
            if (width > col_widths[c]) col_widths[c] = width;
        }
        if (col_widths[c] > 40) col_widths[c] = 40;
    }

    html_append_newline(out, out_len, pos);
    for (r = 0; r < table->num_rows; r++) {
        for (c = 0; c < table->num_cols; c++) {
            const char *cell = table->cells[r][c];
            if (c > 0) {
                html_append_str(out, out_len, pos, "  ");
            }
            html_append_str(out, out_len, pos, cell);
            width = (int)strlen(cell);
            while (width < col_widths[c]) {
                html_append_char(out, out_len, pos, ' ');
                width++;
            }
        }
        html_append_newline(out, out_len, pos);
    }
    html_append_newline(out, out_len, pos);
}

void html_document_init(html_document_t *doc)
{
    memset(doc, 0, sizeof(*doc));
}

void html_parse_document(const char *html, html_document_t *doc)
{
    const char *body;
    const char *body_end;
    const char *p;
    const char *title_open;
    const char *title_close;
    char tag_buf[1024];
    html_table_t *cur_table = NULL;
    int cur_row = -1;
    int cur_col = 0;
    html_form_t *cur_form = NULL;
    int skip_depth = 0;

    html_document_init(doc);

    title_open = html_strcasestr(html, "<title");
    if (title_open) {
        title_open = strchr(title_open, '>');
        title_close = html_strcasestr(title_open ? title_open : html, "</title>");
        if (title_open && title_close && title_close > title_open) {
            html_copy_cell_text(title_open + 1, title_close, doc->title, sizeof(doc->title));
        }
    }

    body = html_body_start(html);
    body_end = html_body_end(html, body);

    p = body;
    while (p < body_end) {
        const char *tag_start = memchr(p, '<', (size_t)(body_end - p));
        const char *tag_end;
        int tag_len;
        int copy_len;

        if (!tag_start) break;
        tag_end = memchr(tag_start, '>', (size_t)(body_end - tag_start));
        if (!tag_end) break;

        tag_len = (int)(tag_end - tag_start + 1);
        copy_len = tag_len >= (int)sizeof(tag_buf) - 1 ?
                   (int)sizeof(tag_buf) - 1 : tag_len;
        strncpy(tag_buf, tag_start, copy_len);
        tag_buf[copy_len] = '\0';
        html_strlower(tag_buf);

        if (html_is_skipped_tag(tag_buf)) {
            skip_depth++;
            p = tag_end + 1;
            continue;
        }
        if (html_is_skipped_close(tag_buf)) {
            if (skip_depth > 0) skip_depth--;
            p = tag_end + 1;
            continue;
        }
        if (skip_depth > 0) {
            p = tag_end + 1;
            continue;
        }

        if (strncmp(tag_buf, "<a ", 3) == 0 ||
                   strncmp(tag_buf, "<a>", 3) == 0) {
            if (doc->num_links < HTML_MAX_LINKS) {
                html_link_t *link = &doc->links[doc->num_links];
                char *link_end = html_strcasestr(tag_end + 1, "</a>");

                html_get_attr(tag_buf, "href", link->url, sizeof(link->url));
                if (link_end) {
                    html_copy_cell_text(tag_end + 1, link_end, link->text, sizeof(link->text));
                } else {
                    link->text[0] = '\0';
                }
                if (link->url[0] != '\0') {
                    doc->num_links++;
                }
            }
        } else if (strncmp(tag_buf, "<form", 5) == 0) {
            if (doc->num_forms < HTML_MAX_FORMS) {
                cur_form = &doc->forms[doc->num_forms];
                memset(cur_form, 0, sizeof(*cur_form));
                cur_form->found = 1;
                strcpy(cur_form->method, "get");
                html_get_attr(tag_buf, "method", cur_form->method, sizeof(cur_form->method));
                html_get_attr(tag_buf, "action", cur_form->action, sizeof(cur_form->action));
                html_strlower(cur_form->method);
                doc->num_forms++;
            }
        } else if (strncmp(tag_buf, "</form", 6) == 0) {
            cur_form = NULL;
        } else if (strncmp(tag_buf, "<input", 6) == 0 && cur_form) {
            if (cur_form->num_inputs < HTML_MAX_FORM_INPUTS) {
                html_input_t *input = &cur_form->inputs[cur_form->num_inputs];
                strcpy(input->type, "text");
                html_get_attr(tag_buf, "name", input->name, sizeof(input->name));
                html_get_attr(tag_buf, "type", input->type, sizeof(input->type));
                html_get_attr(tag_buf, "value", input->value, sizeof(input->value));
                html_strlower(input->type);
                if (input->name[0] != '\0') {
                    cur_form->num_inputs++;
                }
            }
        } else if (strncmp(tag_buf, "<textarea", 9) == 0 && cur_form) {
            if (cur_form->num_inputs < HTML_MAX_FORM_INPUTS) {
                html_input_t *input = &cur_form->inputs[cur_form->num_inputs];
                char *area_end = html_strcasestr(tag_end + 1, "</textarea>");
                strcpy(input->type, "textarea");
                html_get_attr(tag_buf, "name", input->name, sizeof(input->name));
                if (area_end) {
                    html_copy_cell_text(tag_end + 1, area_end, input->value, sizeof(input->value));
                }
                if (input->name[0] != '\0') {
                    cur_form->num_inputs++;
                }
            }
        } else if (strncmp(tag_buf, "<table", 6) == 0) {
            if (doc->num_tables < HTML_MAX_TABLES) {
                cur_table = &doc->tables[doc->num_tables];
                memset(cur_table, 0, sizeof(*cur_table));
                doc->num_tables++;
                cur_row = -1;
                cur_col = 0;
            }
        } else if (strncmp(tag_buf, "</table", 7) == 0) {
            cur_table = NULL;
            cur_row = -1;
        } else if (strncmp(tag_buf, "<tr", 3) == 0 && cur_table) {
            cur_row++;
            cur_col = 0;
            if (cur_row >= HTML_MAX_TABLE_ROWS) {
                cur_row = HTML_MAX_TABLE_ROWS - 1;
            } else if (cur_row + 1 > cur_table->num_rows) {
                cur_table->num_rows = cur_row + 1;
            }
        } else if ((strncmp(tag_buf, "<td", 3) == 0 || strncmp(tag_buf, "<th", 3) == 0) &&
                   cur_table && cur_row >= 0) {
            const char *close_tag = (strncmp(tag_buf, "<th", 3) == 0) ? "</th>" : "</td>";
            const char *cell_end = html_strcasestr(tag_end + 1, close_tag);
            if (cell_end && cur_col < HTML_MAX_TABLE_COLS) {
                html_copy_cell_text(tag_end + 1, cell_end,
                                    cur_table->cells[cur_row][cur_col],
                                    HTML_MAX_CELL_TEXT);
                cur_col++;
                if (cur_col > cur_table->num_cols) {
                    cur_table->num_cols = cur_col;
                }
            }
        }

        p = tag_end + 1;
    }
}

int html_render_text(const char *html, const html_document_t *doc,
                     char *out, int out_len)
{
    const char *body;
    const char *body_end;
    const char *p;
    char tag_buf[1024];
    int pos = 0;
    int skip_depth = 0;
    int table_index = 0;
    int pre_mode = 0;
    int in_table = 0;

    if (out_len <= 0) return -1;
    out[0] = '\0';

    if (doc && doc->title[0] != '\0') {
        html_append_str(out, out_len, &pos, doc->title);
        html_append_newline(out, out_len, &pos);
        html_append_newline(out, out_len, &pos);
    }

    body = html_body_start(html);
    body_end = html_body_end(html, body);

    p = body;
    while (p < body_end) {
        const char *tag_start = memchr(p, '<', (size_t)(body_end - p));
        const char *tag_end;
        int tag_len;
        int copy_len;
        char text_chunk[512];
        int chunk_len;

        if (!tag_start) {
            chunk_len = (int)(body_end - p);
            if (chunk_len >= (int)sizeof(text_chunk)) chunk_len = (int)sizeof(text_chunk) - 1;
            strncpy(text_chunk, p, chunk_len);
            text_chunk[chunk_len] = '\0';
            if (skip_depth == 0 && !in_table) {
                if (html_append_text(out, out_len, &pos, text_chunk, pre_mode) != 0) {
                    return -1;
                }
            }
            break;
        }

        chunk_len = (int)(tag_start - p);
        if (chunk_len > 0 && skip_depth == 0 && !in_table) {
            if (chunk_len >= (int)sizeof(text_chunk)) chunk_len = (int)sizeof(text_chunk) - 1;
            strncpy(text_chunk, p, chunk_len);
            text_chunk[chunk_len] = '\0';
            if (html_append_text(out, out_len, &pos, text_chunk, pre_mode) != 0) {
                return -1;
            }
        }

        tag_end = memchr(tag_start, '>', (size_t)(body_end - tag_start));
        if (!tag_end) break;

        tag_len = (int)(tag_end - tag_start + 1);
        copy_len = tag_len >= (int)sizeof(tag_buf) - 1 ?
                   (int)sizeof(tag_buf) - 1 : tag_len;
        strncpy(tag_buf, tag_start, copy_len);
        tag_buf[copy_len] = '\0';
        html_strlower(tag_buf);

        if (html_is_skipped_tag(tag_buf)) {
            skip_depth++;
        } else if (html_is_skipped_close(tag_buf)) {
            if (skip_depth > 0) skip_depth--;
        } else if (skip_depth == 0) {
            if (strncmp(tag_buf, "<br", 3) == 0 ||
                strncmp(tag_buf, "<hr", 3) == 0) {
                html_append_newline(out, out_len, &pos);
            } else if (strncmp(tag_buf, "<p", 2) == 0 ||
                       strncmp(tag_buf, "<div", 4) == 0 ||
                       strncmp(tag_buf, "<li", 3) == 0 ||
                       strncmp(tag_buf, "<blockquote", 11) == 0 ||
                       strncmp(tag_buf, "<h1", 3) == 0 ||
                       strncmp(tag_buf, "<h2", 3) == 0 ||
                       strncmp(tag_buf, "<h3", 3) == 0 ||
                       strncmp(tag_buf, "<h4", 3) == 0 ||
                       strncmp(tag_buf, "<h5", 3) == 0 ||
                       strncmp(tag_buf, "<h6", 3) == 0) {
                html_append_newline(out, out_len, &pos);
            } else if (strncmp(tag_buf, "</p", 3) == 0 ||
                       strncmp(tag_buf, "</div", 5) == 0 ||
                       strncmp(tag_buf, "</li", 4) == 0 ||
                       strncmp(tag_buf, "</h1", 4) == 0 ||
                       strncmp(tag_buf, "</h2", 4) == 0 ||
                       strncmp(tag_buf, "</h3", 4) == 0 ||
                       strncmp(tag_buf, "</h4", 4) == 0 ||
                       strncmp(tag_buf, "</h5", 4) == 0 ||
                       strncmp(tag_buf, "</h6", 4) == 0) {
                html_append_newline(out, out_len, &pos);
            } else if (strncmp(tag_buf, "<pre", 4) == 0) {
                pre_mode = 1;
                html_append_newline(out, out_len, &pos);
            } else if (strncmp(tag_buf, "</pre", 5) == 0) {
                pre_mode = 0;
                html_append_newline(out, out_len, &pos);
            } else if (strncmp(tag_buf, "<table", 6) == 0 && doc) {
                if (table_index < doc->num_tables) {
                    html_render_table(&doc->tables[table_index], out, out_len, &pos);
                }
                table_index++;
                in_table = 1;
            } else if (strncmp(tag_buf, "</table", 7) == 0) {
                in_table = 0;
            } else if (strncmp(tag_buf, "<form", 5) == 0 && doc) {
                html_append_newline(out, out_len, &pos);
                html_append_str(out, out_len, &pos, "------ Form ------");
                html_append_newline(out, out_len, &pos);
            } else if (strncmp(tag_buf, "<input", 6) == 0 && doc) {
                char name[64];
                char type[16];
                char value[256];
                strcpy(type, "text");
                html_get_attr(tag_buf, "name", name, sizeof(name));
                html_get_attr(tag_buf, "type", type, sizeof(type));
                html_get_attr(tag_buf, "value", value, sizeof(value));
                html_strlower(type);
                if (name[0] != '\0' &&
                    strcmp(type, "hidden") != 0 &&
                    strcmp(type, "submit") != 0 &&
                    strcmp(type, "button") != 0) {
                    html_append_str(out, out_len, &pos, "  [");
                    html_append_str(out, out_len, &pos, name);
                    html_append_str(out, out_len, &pos, "] ");
                    if (value[0] != '\0') {
                        html_append_str(out, out_len, &pos, value);
                    }
                    html_append_newline(out, out_len, &pos);
                }
            } else if (strncmp(tag_buf, "</form", 6) == 0) {
                html_append_str(out, out_len, &pos, "------ End Form ------");
                html_append_newline(out, out_len, &pos);
            }
        }

        p = tag_end + 1;
    }

    return pos;
}

static int html_parse_base_url(const char *url, char *host, int host_len,
                               char *path, int path_len)
{
    const char *p;
    const char *slash;
    const char *colon;
    char hostport[256];

    if (strncmp(url, "https://", 8) == 0) {
        return -1;
    }
    if (strncmp(url, "http://", 7) != 0) {
        return -1;
    }

    p = url + 7;

    slash = strchr(p, '/');
    if (!slash) {
        strncpy(hostport, p, sizeof(hostport) - 1);
        hostport[sizeof(hostport) - 1] = '\0';
        strcpy(path, "/");
    } else {
        int hp_len = (int)(slash - p);
        if (hp_len <= 0 || hp_len >= (int)sizeof(hostport)) return -1;
        strncpy(hostport, p, hp_len);
        hostport[hp_len] = '\0';
        strncpy(path, slash, path_len - 1);
        path[path_len - 1] = '\0';
    }

    colon = strchr(hostport, ':');
    if (colon) {
        int h_len = (int)(colon - hostport);
        if (h_len <= 0 || h_len >= host_len) return -1;
        strncpy(host, hostport, h_len);
        host[h_len] = '\0';
    } else {
        strncpy(host, hostport, host_len - 1);
        host[host_len - 1] = '\0';
    }
    return 0;
}

int html_make_absolute_url(const char *base_url, const char *link,
                           char *out, int out_size)
{
    char base_host[256];
    char base_path[512];
    char resolved_path[512];
    char *slash;
    char *last_slash;

    if (!link || !out || out_size <= 0) return -1;

    if (strncmp(link, "https://", 8) == 0) {
        return -1;
    }
    if (strncmp(link, "http://", 7) == 0) {
        strncpy(out, link, out_size - 1);
        out[out_size - 1] = '\0';
        return 0;
    }

    if (html_parse_base_url(base_url, base_host, sizeof(base_host),
                            base_path, sizeof(base_path)) != 0) {
        return -1;
    }

    if (link[0] == '/') {
        snprintf(out, out_size, "http://%s%s", base_host, link);
        return 0;
    }

    if (strncmp(link, "./", 2) == 0) {
        link += 2;
    }

    strncpy(resolved_path, base_path, sizeof(resolved_path) - 1);
    resolved_path[sizeof(resolved_path) - 1] = '\0';
    last_slash = strrchr(resolved_path, '/');
    if (last_slash) {
        last_slash[1] = '\0';
    } else {
        strcpy(resolved_path, "/");
    }

    while (strncmp(link, "../", 3) == 0) {
        link += 3;
        slash = strrchr(resolved_path, '/');
        if (slash && slash != resolved_path) {
            *slash = '\0';
            slash = strrchr(resolved_path, '/');
            if (slash) {
                slash[1] = '\0';
            }
        }
    }

    snprintf(out, out_size, "http://%s%s%s", base_host, resolved_path, link);
    return 0;
}
