# Lynx-CE — HTTP only (no SSL)

This folder contains a self-contained build of Lynx-CE that uses **plain HTTP over TCP** only. There is no PolarSSL, MbedTLS, or HTTPS support.

Use this version when:

- You do not need TLS/HTTPS
- You want the smallest, simplest build for WinCE 3.0+ devices
- You are targeting legacy HTTP-only sites or local intranet pages

## Files

| File | Purpose |
|------|---------|
| `browser.c` | Main app (g/l/f/q commands) |
| `html_parse.c` / `html_parse.h` | Lynx-style HTML parser (body, links, forms, tables) |
| `net_transport.c` / `net_transport.h` | Plain TCP connect/send/recv |

## Build (CeGCC)

From this directory, with `winsock2.h` in the same folder:

```bash
arm-wince-cegcc-gcc -mwin32 browser.c html_parse.c net_transport.c -o lynx-ce-http.exe
```

If your toolchain needs explicit Winsock linking:

```bash
arm-wince-cegcc-gcc -mwin32 browser.c html_parse.c net_transport.c -o lynx-ce-http.exe -lws2
```

## Usage

- **g** — open a URL (`http://example.com/` only)
- **l** — list and follow numbered links
- **f** — fill in a form and submit (GET or POST)
- **q** — quit

HTTPS URLs are rejected with a clear message. Relative links are resolved to `http://` only.

## Difference from the main tree

The root project includes optional HTTPS routing via `net_transport` and PolarSSL hooks (`USE_POLARSSL`). This folder removes all of that:

- No `USE_POLARSSL` define or TLS types
- No `--tls-insecure` or `--ca-bundle` flags
- No `https://` URL support

For HTTPS on WinCE, use the main project tree and the PolarSSL build notes under `experimental/`.
