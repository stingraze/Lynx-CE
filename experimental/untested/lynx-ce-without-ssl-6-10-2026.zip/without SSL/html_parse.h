#ifndef HTML_PARSE_H
#define HTML_PARSE_H

/*
 * Lynx-style HTML parser for CE-Lynx.
 * Handles body text, links, forms, and tables with naive tag scanning.
 */

#define HTML_MAX_LINKS          100
#define HTML_MAX_FORMS          8
#define HTML_MAX_FORM_INPUTS    16
#define HTML_MAX_TABLES         8
#define HTML_MAX_TABLE_ROWS     64
#define HTML_MAX_TABLE_COLS     16
#define HTML_MAX_CELL_TEXT      128
#define HTML_MAX_TITLE          256

typedef struct {
    char text[128];
    char url[512];
} html_link_t;

typedef struct {
    char name[64];
    char type[16];
    char value[256];
} html_input_t;

typedef struct {
    char method[16];
    char action[512];
    int  found;
    int  num_inputs;
    html_input_t inputs[HTML_MAX_FORM_INPUTS];
} html_form_t;

typedef struct {
    int num_rows;
    int num_cols;
    char cells[HTML_MAX_TABLE_ROWS][HTML_MAX_TABLE_COLS][HTML_MAX_CELL_TEXT];
} html_table_t;

typedef struct {
    char title[HTML_MAX_TITLE];
    html_link_t links[HTML_MAX_LINKS];
    int num_links;
    html_form_t forms[HTML_MAX_FORMS];
    int num_forms;
    html_table_t tables[HTML_MAX_TABLES];
    int num_tables;
} html_document_t;

void html_document_init(html_document_t *doc);

/* Parse links, forms, tables, and title from raw HTML (full page or body). */
void html_parse_document(const char *html, html_document_t *doc);

/*
 * Render HTML as Lynx-like plain text into out (NUL-terminated).
 * Uses doc for table layout; re-parses inline structure from html.
 * Returns bytes written excluding NUL, or -1 if out is too small.
 */
int html_render_text(const char *html, const html_document_t *doc,
                     char *out, int out_len);

/*
 * Resolve link or form action against base URL (http only).
 * Returns 0 on success, -1 if base URL is invalid or HTTPS is requested.
 */
int html_make_absolute_url(const char *base_url, const char *link,
                           char *out, int out_size);

/* Decode common HTML entities in place (&amp;, &lt;, &nbsp;, numeric). */
void html_decode_entities(char *text);

#endif
