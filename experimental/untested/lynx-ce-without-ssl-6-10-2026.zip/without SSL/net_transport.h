#ifndef NET_TRANSPORT_H
#define NET_TRANSPORT_H

/*
 * Plain HTTP transport for Lynx-CE (no TLS / no PolarSSL).
 */

#include "winsock2.h"

#define NET_TRANSPORT_ERR -1

typedef struct {
    SOCKET socket_fd;
} net_transport_t;

int net_transport_connect(net_transport_t *transport,
                          const char *host,
                          unsigned short port);

int net_transport_send(net_transport_t *transport, const void *data, int len);
int net_transport_recv(net_transport_t *transport, void *buffer, int len);
void net_transport_close(net_transport_t *transport);

#endif
