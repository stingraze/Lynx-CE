#include "net_transport.h"

#include <string.h>

static int tcp_connect_socket(const char *host, unsigned short port)
{
    struct hostent *he = gethostbyname(host);
    if (!he) {
        return INVALID_SOCKET;
    }

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) {
        return INVALID_SOCKET;
    }

    struct sockaddr_in server;
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    server.sin_addr.s_addr = *((u_long*)he->h_addr);

    if (connect(s, (struct sockaddr*)&server, sizeof(server)) != 0) {
        closesocket(s);
        return INVALID_SOCKET;
    }

    return s;
}

int net_transport_connect(net_transport_t *transport,
                          const char *host,
                          unsigned short port)
{
    memset(transport, 0, sizeof(*transport));
    transport->socket_fd = tcp_connect_socket(host, port);
    if (transport->socket_fd == INVALID_SOCKET) {
        return NET_TRANSPORT_ERR;
    }
    return 0;
}

int net_transport_send(net_transport_t *transport, const void *data, int len)
{
    return send(transport->socket_fd, (const char*)data, len, 0);
}

int net_transport_recv(net_transport_t *transport, void *buffer, int len)
{
    return recv(transport->socket_fd, (char*)buffer, len, 0);
}

void net_transport_close(net_transport_t *transport)
{
    if (!transport) return;
    if (transport->socket_fd != INVALID_SOCKET) {
        closesocket(transport->socket_fd);
        transport->socket_fd = INVALID_SOCKET;
    }
}
